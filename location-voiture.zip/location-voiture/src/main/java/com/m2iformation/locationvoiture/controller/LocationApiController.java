package com.m2iformation.locationvoiture.controller;


import com.m2iformation.locationvoiture.model.Location;
import com.m2iformation.locationvoiture.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class LocationApiController {


    @Autowired
    private LocationRepository locationRepository;

    @GetMapping(path="/api/locations")
    public Iterable<Location> lcoationList(){

        return locationRepository.findLocationByClientName("Lati");
    }

    @DeleteMapping(path="/api/locations/{id}")
    public @ResponseBody int deleteLocation(@PathVariable Long id){
        Optional<Location> v = locationRepository.findById(id);
        locationRepository.delete(v.get());
        return 204;
    }

    @PostMapping(path="/api/locations")
    public ResponseEntity<Location> addLocation(
            @RequestBody Location x
    ){
        Location createdCar = locationRepository.save(x);
        System.out.println(createdCar);
        if(createdCar==null){
            return ResponseEntity.ok(createdCar);
        }else{
            return  ResponseEntity.ok(createdCar);
        }
    }


//    @PutMapping(path="/api/locations/{id}")
//    public ResponseEntity<Location> updateLocation(
//            @PathVariable Long id,
//            @RequestBody Location x
//    ){
//        x.setId(id);
//        Location createdCar = locationRepository.save(x);
//        if(createdCar==null){
//            return ResponseEntity.ok(createdCar);
//        }else{
//            return  ResponseEntity.ok(createdCar);
//        }
//    }




}

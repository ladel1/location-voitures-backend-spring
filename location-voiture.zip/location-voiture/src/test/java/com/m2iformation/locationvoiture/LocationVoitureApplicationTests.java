package com.m2iformation.locationvoiture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationVoitureApplicationTests {

	@Test
	void contextLoads() {
	}

}
